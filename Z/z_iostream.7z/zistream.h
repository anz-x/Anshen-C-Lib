/* @authors:

       /-----------/
     /--------/  /
            /  /
          /  /
        /  /
      /  /--------/
    /-----------/       C++ Third-party Lib. Anz

*/

// help: https://www.luogu.com.cn/record/256836679

#pragma once
#ifndef Z_ISTREAM
#define Z_ISTREAM

#include <stdint.h>
#include <string>

namespace Z {
    /*
    @brief
    ** We provides faster input tools, especially for reading integers.
    ** but we set "in" as the default input source to avoid too many "Ctrl+Z"s.
    */
    extern "C++" void __fastcall tie(const char *file);
    extern "C++" int32_t __fastcall read_i32();
    extern "C++" uint32_t __fastcall read_u32();
    extern "C++" int64_t __fastcall read_i64();
    extern "C++" uint64_t __fastcall read_u64();
    extern "C++" double __fastcall read_double();
    extern "C++" std::string __fastcall read_string();
    extern "C++" void __fastcall read_cstr(char *str);
    extern "C++" void __fastcall read_line(char *str);
    extern "C++" char __fastcall read_char();
}

#endif /* END OF Z_ISTREAM */