/* @authors:

       /-----------/
     /--------/  /
            /  /
          /  /
        /  /
      /  /--------/
    /-----------/       C++ Third-party Lib. Anz

*/

// help: https://www.luogu.com.cn/record/145628562

#pragma once
#ifndef Z_OSTREAM
#define Z_OSTREAM

#include <stdint.h>
#include <string>

namespace Z {
    /*
    @brief
    ** zout lib provides faster output tools, especially for writing integers.
    ** we set stdout as the default output destination.
    */
    extern "C++" void __fastcall tie1(const char *file);
    extern "C++" void __fastcall write(int32_t);
    extern "C++" void __fastcall write(uint32_t);
    extern "C++" void __fastcall write(int64_t);
    extern "C++" void __fastcall write(uint64_t);
    extern "C++" void __fastcall set_precision(int cnt);
    extern "C++" void __fastcall write(double);
    extern "C++" void __fastcall write(std::string);
    extern "C++" void __fastcall write(char *str);
    extern "C++" char __fastcall write(char);
}

#endif /* END OF Z_OSTREAM */