- compile:
g++ zin.cpp -O3 -Os -fomit-frame-pointer -flto -fPIC -shared -o z_in.so
strip --strip-unneeded z_in.so

g++ zout.cpp -O3 -Os -fomit-frame-pointer -flto -fPIC -shared -o z_out.so
strip --strip-unneeded z_out.so


- place:
z_in.so -> mingw/bin/
z_out.so -> mingw/bin/
zistream.h -> mingw/include/
zostream.h -> mingw/include/
ziostream -> mingw/include/