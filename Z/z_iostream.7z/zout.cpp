#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <string>

namespace Z
{
    char x[(10000 << 2) | 1];
#define maxn 0x10000
    char obf[maxn];
    int ops;
    int pre = 6;
#define obs obf[ops]
#define obp obf[ops++]

    FILE *fp = stdout;

    [[gnu::always_inline]] __attribute__((constructor)) inline void __fastcall block_init()
    {
        int j = 0, k = 0;
        for (int i = 0; i < 10000; ++i)
        {
            j = 4, k = i;
            while (j--)
            {
                x[(i << 2) + j] = k % 10 | '0';
                k /= 10;
            }
        }
    }

    [[gnu::always_inline]] __attribute__((destructor)) inline void __fastcall flush()
    {
        fwrite_unlocked(obf, 1, ops, fp);
        ops = 0;
    }

    [[gnu::always_inline]] inline constexpr int __fastcall get_integer_size(uint64_t n)
    {
        if (n >= 10000000000000000000u)
            return 20;
        if (n >= 1000000000000000000)
            return 19;
        if (n >= 100000000000000000)
            return 18;
        if (n >= 10000000000000000)
            return 17;
        if (n >= 1000000000000000)
            return 16;
        if (n >= 100000000000000)
            return 15;
        if (n >= 10000000000000)
            return 14;
        if (n >= 1000000000000)
            return 13;
        if (n >= 100000000000)
            return 12;
        if (n >= 10000000000)
            return 11;
        if (n >= 1000000000)
            return 10;
        if (n >= 100000000)
            return 9;
        if (n >= 10000000)
            return 8;
        if (n >= 1000000)
            return 7;
        if (n >= 100000)
            return 6;
        if (n >= 10000)
            return 5;
        if (n >= 1000)
            return 4;
        if (n >= 100)
            return 3;
        if (n >= 10)
            return 2;
        return 1;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall tie1(const char *s)
    {
        fp = s ? fopen(s, "w") : stdout;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall set_precision(int cnt)
    {
        pre = cnt < 1 ? 1 : cnt;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall write(int32_t v)
    {
        if (__builtin_expect(ops + 10 >= maxn, 0))
            flush();
        if (v < 0)
            obp = '-', v = -v;
        int d = get_integer_size(v);
        int l = d;
        while (l >= 4)
        {
            l -= 4;
            memcpy(obf + ops + l, x + ((v % 10000) << 2), 4);
            v /= 10000;
        }
        memcpy(obf + ops, x + (v << 2) + (4 - l), l);
        ops += d;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall write(int64_t v)
    {
        if (__builtin_expect(ops + 21 >= maxn, 0))
            flush();
        if (v < 0)
            obp = '-', v = -v;
        int d = get_integer_size(v);
        int l = d;
        while (l >= 4)
        {
            l -= 4;
            memcpy(obf + ops + l, x + ((v % 10000) << 2), 4);
            v /= 10000;
        }
        memcpy(obf + ops, x + (v << 2) + (4 - l), l);
        ops += d;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall write(uint32_t v)
    {
        if (__builtin_expect(ops + 10 >= maxn, 0))
            flush();
        int d = get_integer_size(v);
        int l = d;
        while (l >= 4)
        {
            l -= 4;
            memcpy(obf + ops + l, x + ((v % 10000) << 2), 4);
            v /= 10000;
        }
        memcpy(obf + ops, x + (v << 2) + (4 - l), l);
        ops += d;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall write(uint64_t v)
    {
        if (__builtin_expect(ops + 21 >= maxn, 0))
            flush();
        int d = get_integer_size(v);
        int l = d;
        while (l >= 4)
        {
            l -= 4;
            memcpy(obf + ops + l, x + ((v % 10000) << 2), 4);
            v /= 10000;
        }
        memcpy(obf + ops, x + (v << 2) + (4 - l), l);
        ops += d;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall write(double v)
    {
        if (__builtin_expect(ops + 45 >= maxn, 0))
            flush();
        int64_t z = v;
        v -= (double)z;
        int d = get_integer_size(z);
        int l = d;
        while (l >= 4)
        {
            l -= 4;
            memcpy(obf + ops + l, x + ((z % 10000) << 2), 4);
            z /= 10000;
        }
        memcpy(obf + ops, x + (z << 2) + (4 - l), l);
        ops += d;
        obp = '.';
        if (__builtin_expect(ops >= maxn, 0))
            flush();
        double p = 0.5, e = __builtin_pow(10, pre);
        v += p / e;
        v *= e;
        z = (int64_t)v;
        d = get_integer_size(z);
        l = d;
        while (l >= 4)
        {
            l -= 4;
            memcpy(obf + ops + l, x + ((z % 10000) << 2), 4);
            z /= 10000;
        }
        memcpy(obf + ops, x + (z << 2) + (4 - l), l);
        ops += d;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall write(char c)
    {
        obp = c;
        if (__builtin_expect(ops >= maxn, 0))
            flush();
    }

    extern "C++" [[gnu::always_inline]] void __fastcall write(char *s)
    {
        int l = strlen(s), p = 0;
        if (__builtin_expect(ops + l >= maxn, 0))
            flush();
        while (l >= maxn)
        {
            memmove(obf, s + p, ops = maxn);
            p += maxn, l -= maxn;
            flush();
        }
        memmove(obf + ops, s + p, l);
        ops += l;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall write(std::string s)
    {
        for (char c : s)
        {
            obp = c;
            if (__builtin_expect(ops >= maxn, 0))
                flush();
        }
    }

}