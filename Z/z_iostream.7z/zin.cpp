#include <iostream>
#include <ctype.h>
#include <fstream>
#include <stdint.h>
#include <string>

namespace Z
{
    int x[0x10000] = {};

    std::ifstream in;

#define maxn 0x10000
    char ibf[maxn];
    int ips = 0, ipe = 0;
#define ibs ibf[ips]
#define ibp ibf[ips++]

    [[gnu::always_inline]] __attribute__((constructor)) inline void __fastcall begin()
    {
        std::ios::sync_with_stdio(0); // faster
        std::cin.tie(0);
        __builtin_memset(x, -1, 0x40000);
        for (int i = 48; i <= 57; ++i)
            for (int j = 48; j <= 57; ++j)
                x[i << 8 | j] = (j & 15) * 10 + (i & 15);
    }

    [[gnu::always_inline]] __attribute__((destructor)) inline void __fastcall end()
    {
        in.close();
    }

    [[gnu::always_inline]] inline void __fastcall refresh()
    {
        int len = ipe - ips;
        __builtin_memcpy(ibf, ibf + ips, len);
        ipe = len + std::cin.rdbuf()->sgetn(ibf + len, maxn - len);
        ibf[ipe] = EOF;
        ips = 0;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall tie(const char *s)
    {
        in.close();
        in.open(s);
        std::cin.rdbuf(in.rdbuf());
    }

    extern "C++" [[gnu::always_inline]] int32_t __fastcall read_i32()
    {
        if (__builtin_expect(ipe <= ips + 18, 0))
            refresh();
        while (__builtin_expect(isspace(ibs), 0))
        {
            if (__builtin_expect(ipe <= ips, 0))
                refresh();
            ++ips;
        }
        bool f = 0;
        int32_t v = 0;
        ips += f = (ibs == 45);
        __builtin_expect(~x[*(uint16_t *)(&ibs)], 1) && (v = x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            isdigit(ibs) && (v = v * 10 + (15 & ibp)), v = (f ? -v : v);
        ips++;
        return v;
    }

    extern "C++" [[gnu::always_inline]] int64_t __fastcall read_i64()
    {
        if (__builtin_expect(ipe <= ips + 29, 0))
            refresh();
        while (__builtin_expect(isspace(ibs), 0))
        {
            if (__builtin_expect(ipe <= ips, 0))
                refresh();
            ++ips;
        }
        bool f = 0;
        int64_t v = 0;
        ips += f = (ibs == 45);
        __builtin_expect(~x[*(uint16_t *)(&ibs)], 1) && (v = x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            isdigit(ibs) && (v = v * 10 + (15 & ibp)), v = (f ? -v : v);
        ips++;
        return v;
    }

    extern "C++" [[gnu::always_inline]] uint32_t __fastcall read_u32()
    {
        if (__builtin_expect(ipe <= ips + 18, 0))
            refresh();
        while (__builtin_expect(isspace(ibs), 0))
        {
            if (__builtin_expect(ipe <= ips, 0))
                refresh();
            ++ips;
        }
        uint32_t v = 0;
        __builtin_expect(~x[*(uint16_t *)(&ibs)], 1) && (v = x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            isdigit(ibs) && (v = v * 10 + (15 & ibp));
        ips++;
        return v;
    }

    extern "C++" [[gnu::always_inline]] uint64_t __fastcall read_u64()
    {
        if (__builtin_expect(ipe <= ips + 29, 0))
            refresh();
        while (__builtin_expect(isspace(ibs), 0))
        {
            if (__builtin_expect(ipe <= ips, 0))
                refresh();
            ++ips;
        }
        uint64_t v = 0;
        __builtin_expect(~x[*(uint16_t *)(&ibs)], 1) && (v = x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (v = v * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            isdigit(ibs) && (v = v * 10 + (15 & ibp));
        ips++;
        return v;
    }

    extern "C++" [[gnu::always_inline]] double __fastcall read_double()
    {
        if (__builtin_expect(ipe <= ips + 72, 0))
            refresh();
        while (__builtin_expect(isspace(ibs), 0))
        {
            if (__builtin_expect(ipe <= ips, 0))
                refresh();
            ++ips;
        }
        bool f = 0;
        int64_t z = 0;
        ips += f = (ibs == 45);
        __builtin_expect(~x[*(uint16_t *)(&ibs)], 1) && (z = x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            (~x[*(uint16_t *)(&ibs)]) && (z = z * 100 + x[*(uint16_t *)(&ibs)], ips += 2),
            isdigit(ibs) && (z = z * 10 + (15 & ibp));
        if (ibp != '.')
            return f ? -z : z;
        double v = 0, d = 0.1;
        __builtin_expect(~x[*(uint16_t *)(&ibs)], 1) && (v = x[*(uint16_t *)(&ibs)] * 0.01, ips += 2, d = 0.001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.0001, ips += 2, d = 0.00001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.000001, ips += 2, d = 0.0000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.00000001, ips += 2, d = 0.000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.0000000001, ips += 2, d = 0.00000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.000000000001, ips += 2, d = 0.0000000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.00000000000001, ips += 2, d = 0.000000000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.0000000000000001, ips += 2, d = 0.00000000000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.000000000000000001, ips += 2, d = 0.0000000000000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.00000000000000000001, ips += 2, d = 0.000000000000000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.0000000000000000000001, ips += 2, d = 0.00000000000000000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.000000000000000000000001, ips += 2, d = 0.0000000000000000000000001),
            (~x[*(uint16_t *)(&ibs)]) && (v += x[*(uint16_t *)(&ibs)] * 0.00000000000000000000000001, ips += 2, d = 0.000000000000000000000000001),
            isdigit(ibs) && (v += (15 & ibp) * d);
        ips++;
        return f ? -(v + z) : (v + z);
    }

    extern "C++" [[gnu::always_inline]] char __fastcall read_char()
    {
        if (__builtin_expect(ips >= ipe, 0))
            refresh();
        return ibp;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall read_cstr(char *s)
    {
        char *t = s;
        if (__builtin_expect(ips >= ipe, 0))
            refresh();
        while (isspace(ibs))
        {
            if (__builtin_expect(ips >= ipe, 0))
                refresh();
            ips++;
        }
        while (ibs != EOF)
        {
            if (__builtin_expect(ips >= ipe, 0))
                refresh();
            if (isspace(ibs))
                break;
            *t++ = ibp;
        }
        *t = 0;
    }

    extern "C++" [[gnu::always_inline]] void __fastcall read_line(char *s)
    {
        char *t = s;
        if (__builtin_expect(ips >= ipe, 0))
            refresh();
        while (isspace(ibs))
        {
            if (__builtin_expect(ips >= ipe, 0))
                refresh();
            ips++;
        }
        while (ibs != EOF)
        {
            if (__builtin_expect(ips >= ipe, 0))
                refresh();
            if (ibs == '\n')
                break;
            *t++ = ibp;
        }
        *t = 0;
    }

    extern "C++" [[gnu::always_inline]] std::string __fastcall read_string()
    {
        std::string s = "";
        if (__builtin_expect(ips >= ipe, 0))
            refresh();
        while (isspace(ibs))
        {
            if (__builtin_expect(ips >= ipe, 0))
                refresh();
            ips++;
        }
        while (ibs != EOF)
        {
            if (__builtin_expect(ips >= ipe, 0))
                refresh();
            if (isspace(ibs))
                break;
            s += ibp;
        }
        return s;
    }

}