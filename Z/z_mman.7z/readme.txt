- compile:
g++ mman.cpp -O3 -Os -fomit-frame-pointer -flto -fPIC -shared -o z_sysmman.so
strip --strip-unneeded z_sysmman.so

- place:
z_sysmman.so -> mingw/bin/
mman.h -> mingw/include/