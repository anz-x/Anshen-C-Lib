/* @authors:
 * sys/mman.h
 * mman-win32
*/

// project src: https://github.com/alitrack/mman-win32.git

/* @authors:

       /-----------/
     /--------/  /
            /  /
          /  /
        /  /
      /  /--------/
    /-----------/       C++ Third-party Lib. Anz

*/

#ifndef _SYS_MMAN_H_
#define _SYS_MMAN_H_

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

/* All the headers include this file. */
#ifndef _MSC_VER
#include <_mingw.h>
#endif

/* Determine offset type */
#include <stdint.h>
#if defined(_WIN64)
typedef int64_t OffsetType;
#else
typedef uint32_t OffsetType;
#endif

#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PROT_NONE       0x00
#define PROT_READ       0x01
#define PROT_WRITE      0x02
#define PROT_EXEC       0x04

#define MAP_FILE        0x00
#define MAP_SHARED      0x01
#define MAP_PRIVATE     0x02
#define MAP_TYPE        0x0f
#define MAP_FIXED       0x10
#define MAP_ANONYMOUS   0x20
#define MAP_ANON        MAP_ANONYMOUS

#define MAP_FAILED      ((void *)-1)

/* Flags for msync. */
#define MS_ASYNC        0x01
#define MS_SYNC         0x02
#define MS_INVALIDATE   0x04

void*   __fastcall      mmap(void *addr, size_t len, int prot, int flags, int fildes, OffsetType off);
int     __fastcall      munmap(void *addr, size_t len);
int     __fastcall      _mprotect(void *addr, size_t len, int prot);
int     __fastcall      msync(void *addr, size_t len, int flags);
int     __fastcall      mlock(const void *addr, size_t len);
int     __fastcall      munlock(const void *addr, size_t len);

#ifdef __cplusplus
}
#endif

#endif /*  _SYS_MMAN_H_ */