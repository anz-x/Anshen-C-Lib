#include "io(for luogu).h"
#include "complex(for luogu).h"
#include <anshen/matrix>
using namespace anshen;
#define maxn 10000001
complex a[maxn], b[maxn], ans[maxn];
int type = 1;
int extend_n = 1;
int butterfly[maxn];

void swap(complex& c1, complex& c2) {
    complex temp(c1);
    c1 = c2;
    c2 = temp;
}
void FFT(complex *arr) {
    xfor(i, 0, extend_n - 1) {
        if (i < butterfly[i])
            swap(arr[i], arr[butterfly[i]]); // 即构造蝴蝶序列，i < butterfly是固定搭配，作用是防止二次交换
    } // 整个for循环的作用就是得到最后的蝴蝶序列
    for (int mid = 1; mid < extend_n; mid <<= 1) { // 此时mid = n / 2，但每次单位根是w(n,k)
        complex w0;
        w0.toUnitRoot(mid << 1); // w0 = w(n, 0)
        if (type == -1) w0 = w0.conjugate(); // 否则傅里叶反变换
        int len = mid << 1; // 每次往上（逆递归）的区间大小，逆BFS
        for (int p = 0; p < extend_n; p += len) {
            complex wn(1, 0);
            for (int offset = 0; offset < mid; ++offset, wn = wn * w0) { // wn = w(n, k) = w(n, offset)
                complex F1 = arr[p + offset];
                complex F2 = arr[p + offset + mid];
                arr[p + offset] = F1 + (wn * F2);
                arr[p + offset + mid] = F1 - (wn * F2);
            }
        }
    }

}

main() {
    int n, m, temp;
    io >> n >> m;
    xfor(i, 0, n) {
        io >> temp;
        a[i] = temp;
    }
    xfor(i, 0, m) {
        io >> temp;
        b[i] = temp;
    }

    temp = 0;
    while (extend_n < m + n + 1) { // 答案一共m + n + 1项，要把它补充到2次幂项数方便FFT
        extend_n <<= 1,
        ++temp;
    }

    xfor(i, 0, extend_n - 1) {
        butterfly[i] = (butterfly[i >> 1] >> 1) | ((i & 1) << (temp - 1)); // 二进制对称变换，构造最终的蝴蝶下标序列
    }

    FFT(a);
    FFT(b);
    xfor(i, 0, extend_n) {
        ans[i] = a[i] * b[i];
    }

    type = -1;
    FFT(ans);

    xfor (i, 0, m + n) {
        io << (int)(ans[i].getreal() / extend_n + 0.5) << ' ';
    }
}