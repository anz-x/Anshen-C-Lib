#include <sstream>
namespace anshen {
    class complex {
    double real = 0, imag = 0;
    public:
    complex(double nreal, double nimag) {
        real = nreal, imag = nimag;
    }
    complex(double nreal) {
        real = nreal;
    }
    complex(complex&& other) {
        real = other.real, imag = other.imag;
    }
    complex(const complex& other) {
        real = other.real, imag = other.imag;
    }
    complex() {}
    complex operator+(const complex &other) const {
        return complex(real + other.real, imag + other.imag);
    }
    complex operator+(double add) const {
        return complex(real + add, imag);
    }
    complex operator-(const complex &other) const {
        return complex(real - other.real, imag - other.imag);
    }
    complex operator-(double sub) const {
        return complex(real - sub, imag);
    }
    complex operator*(const complex &other) const {
        double nreal = real * other.real - imag * other.imag;
        double nimag = real * other.imag + imag * other.real;
        return complex(nreal, nimag);
    }
    complex& operator=(complex &&other) {
        real = other.real, imag = other.imag;
        return *this;
    }
    complex& operator=(const complex &other) {
        real = other.real, imag = other.imag;
        return *this;
    }
    complex& operator=(double tar) {
        real = tar, imag = 0;
        return *this;
    }
    complex conjugate() const {
        return complex(real, -imag);
    }
    std::string toString() const {
        std::stringstream sstr;
        sstr << real;
        if (imag > 1e-6 || -imag > 1e-6)
            sstr << " + " << imag << 'i';
		return sstr.str();
    }
#define Pi (3.14159265358979)
    void toUnitRoot(unsigned int n = 1) {
        real = __builtin_cos(2 * Pi / n),
        imag = __builtin_sin(2 * Pi / n);
    }
    void toUnitRootPow(unsigned int pow, unsigned int n = 1) {
        real = __builtin_cos(2 * pow * Pi / n),
        imag = __builtin_sin(2 * pow * Pi / n);
    }
    void assign(double nreal, double nimag) {
        real = nreal, imag = nimag;
    }
    double getmod() const {
        return __builtin_sqrt(real * real + imag * imag);
    }
    const double getreal() const {
        return real;
    }
    const double getimag() const {
        return imag;
    }
#undef Pi
    };
    inline complex operator+(double add, const complex& com) {
        return com + complex(add, 0);
    }
    inline complex operator-(double sub, const complex& com) {
        return complex(sub, 0) - com;
    }
    inline complex operator""_i (long double x){
        return complex(0, (double)x);
    }
}