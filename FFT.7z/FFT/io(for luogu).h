#include <stdio.h> // FOR LUOGU
namespace anshen {
#define __fastcall
#define                      __builtin_fread fread
#define                      __builtin_getchar(  ) fgetc(_istream)
#define                      __builtin_putchar(Ch) fputc(Ch, _ostream)
    extern "C++" {
    FILE* _istream = stdin;
    FILE* _ostream = stdout;
    extern "C++" inline int __fastcall __fastest_getchar() {
        static char _Buf[1 << 16];
        static char *_Ptr = nullptr, *_End = nullptr;
        if (_Ptr == _End)
            _Ptr = _Buf,
            _End = _Buf + __builtin_fread(_Buf, 1u, 1 << 16, _istream);
        return _Ptr == _End ? -1 : *_Ptr++;
    }
    extern "C++" inline int __fastcall __fastest_putchar(int _Ch) {
        static char _Buf[1 << 16], *_Ptr = _Buf;
        if (_Ch == -1)
            return __builtin_fwrite(_Buf, 1u, (_Ptr - _Buf), _ostream);
        *_Ptr++ = _Ch;
        if (_Buf + (1 << 16) == _Ptr)
            __builtin_fwrite(_Buf, 1u, _Ptr - (_Ptr = _Buf), _ostream);
        return 0;
    }
#define __ParseInt() {                                     \
        _Val = 0;                                          \
        bool _Sgn = false;                                 \
        int _Ch = __builtin_getchar();                     \
        while (!__builtin_isdigit(_Ch))                    \
            _Sgn = (_Ch == 45) ? true : false,             \
            _Ch = __builtin_getchar();                     \
        while (__builtin_isdigit(_Ch))                     \
            _Val = (_Val << 1) + (_Val << 3) + (_Ch ^ 48), \
            _Ch = __builtin_getchar();                     \
        _Val = _Sgn ? -_Val : _Val;                        \
    }
    extern "C++" inline void __fastcall read(int &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall read(long &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall read(short &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall read(long long &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall read(unsigned int &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall read(unsigned long &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall read(unsigned short &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall read(unsigned long long &_Val) { __ParseInt(); }
#undef  __ParseInt
    extern "C++" inline void __fastcall read(char *_Str) {
        int _Ch = __builtin_getchar();
        while (!__builtin_isgraph(_Ch)) _Ch = __builtin_getchar();
        do *_Str++ = _Ch;
        while (__builtin_isgraph(_Ch = __builtin_getchar()));
        *_Str = 0;
    }
    extern "C++" inline void __fastcall read(char &_Ch) {
        do _Ch = __builtin_getchar();
        while (!__builtin_isgraph(_Ch));
    }
#define __ParseFloat() {                                               \
        __float128 Fra = _Val = 0;                                     \
        int Sf = 0, Fch = 0, _Ch = __builtin_getchar();                \
        while (!__builtin_isdigit(_Ch) && _Ch != '.')                  \
            Sf = (_Ch == '-'), _Ch = __builtin_getchar();              \
        while (__builtin_isdigit(_Ch) && _Ch != '.')                   \
            _Val = _Val * 10 + (_Ch ^ '0'), _Ch = __builtin_getchar(); \
        if (_Ch == '.') _Ch = __builtin_getchar();                     \
        else return void(_Val = Sf ? -_Val : _Val);                    \
        while (Fch++, __builtin_isdigit(_Ch))                          \
            Fra = Fra * 10 + (_Ch ^ '0'), _Ch = __builtin_getchar();   \
        while (--Fch) Fra /= 10.0;                                     \
        _Val = Sf ? -(_Val + Fra) : (_Val + Fra);                      \
    }
    extern "C++" inline void __fastcall read(float &_Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall read(double &_Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall read(__float128 &_Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall read(long double &_Val) { __ParseFloat(); }
#undef  __ParseFloat
#define __ParseInt() {                                     \
        _Val = 0;                                          \
        bool _Sgn = false;                                 \
        int _Ch = __fastest_getchar();                     \
        while (!__builtin_isdigit(_Ch))                    \
            _Sgn = (_Ch == 45) ? true : false,             \
            _Ch = __fastest_getchar();                     \
        while (__builtin_isdigit(_Ch))                     \
            _Val = (_Val << 1) + (_Val << 3) + (_Ch ^ 48), \
            _Ch = __fastest_getchar();                     \
        _Val = _Sgn ? -_Val : _Val;                        \
    }
    extern "C++" inline void __fastcall fread(int &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fread(long &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fread(short &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fread(long long &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fread(unsigned int &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fread(unsigned long &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fread(unsigned short &_Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fread(unsigned long long &_Val) { __ParseInt(); }
#undef  __ParseInt
    extern "C++" inline void __fastcall fread(char *_Str) {
        int _Ch = __fastest_getchar();
        while (!__builtin_isgraph(_Ch)) _Ch = __fastest_getchar();
        do *_Str++ = _Ch;
        while (__builtin_isgraph(_Ch = __fastest_getchar()));
        *_Str = 0;
    }
    extern "C++" inline void __fastcall fread(char &_Ch) {
        do _Ch = __fastest_getchar();
        while (!__builtin_isgraph(_Ch));
    }
#define __ParseFloat() {                                               \
        __float128 Fra = _Val = 0;                                     \
        int Sf = 0, Fch = 0, _Ch = __fastest_getchar();                \
        while (!__builtin_isdigit(_Ch) && _Ch != '.')                  \
            Sf = (_Ch == '-'), _Ch = __fastest_getchar();              \
        while (__builtin_isdigit(_Ch) && _Ch != '.')                   \
            _Val = _Val * 10 + (_Ch ^ '0'), _Ch = __fastest_getchar(); \
        if (_Ch == '.') _Ch = __fastest_getchar();                     \
        else return void(_Val = Sf ? -_Val : _Val);                    \
        while (Fch++, __builtin_isdigit(_Ch))                          \
            Fra = Fra * 10 + (_Ch ^ '0'), _Ch = __fastest_getchar();   \
        while (--Fch) Fra /= 10.0;                                     \
        _Val = Sf ? -(_Val + Fra) : (_Val + Fra);                      \
    }
    extern "C++" inline void __fastcall fread(float &_Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall fread(double &_Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall fread(__float128 &_Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall fread(long double &_Val) { __ParseFloat(); }
#undef  __ParseFloat
#define __ParseInt() {                                      \
        if (_Val == 0) return void(__builtin_putchar('0')); \
        if (_Val < 0) __builtin_putchar('-'), _Val = -_Val; \
        static int Sta[1 << 5];                             \
        int Top = 0;                                        \
        while (_Val > 0)                                    \
            Sta[++Top] = _Val % 10, _Val /= 10;             \
        while (Top > 0)                                     \
            __builtin_putchar(Sta[Top--] | '0');            \
    }
    extern "C++" inline void __fastcall write(int _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall write(long _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall write(short _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall write(long long _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall write(unsigned int _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall write(unsigned long _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall write(unsigned short _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall write(unsigned long long _Val) { __ParseInt(); }
#undef  __ParseInt
    extern "C++" inline void __fastcall write(char _Ch) { __builtin_putchar(_Ch); }
#define __ParseCharArr() {                                \
        int Ptr = 0;                                      \
        while (_Str[Ptr]) __builtin_putchar(_Str[Ptr++]); \
    }
    extern "C++" inline void __fastcall write(char *_Str) { __ParseCharArr(); }
    extern "C++" inline void __fastcall write(const char *_Str) { __ParseCharArr(); }
#undef  __ParseCharArr
    unsigned short _Prec = 6;
#define __ParseFloat() {                                         \
        __float128 Up = 5;                                       \
        static int Sta[1 << 6];                                  \
        int Top = 0, _It;                                        \
        if (_Val < 0) __builtin_putchar('-'), _Val = -_Val;      \
        for (_It = 0; _It <= _Prec; ++_It) Up /= 10.0;           \
        _Val += Up;                                              \
        long long Par = _Val;                                    \
        _Val -= (__float128)Par;                                 \
        while (Par > 0) Sta[++Top] = Par % 10, Par /= 10;        \
        if (Top == 0) __builtin_putchar('0');                    \
        while (Top > 0) __builtin_putchar(Sta[Top--] | '0');     \
        __builtin_putchar('.'), _It = 0;                         \
        for (; _It < _Prec; ++_It) _Val *= 10;                   \
        Par = _Val, _It = 0;                                     \
        while (Par > 0) Sta[++Top] = Par % 10, Par /= 10;        \
        for (; _It < _Prec - Top; ++_It) __builtin_putchar('0'); \
        while (Top > 0) __builtin_putchar(Sta[Top--] | '0');     \
    }
    extern "C++" inline void __fastcall write(float _Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall write(double _Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall write(__float128 _Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall write(long double _Val) { __ParseFloat(); }
#undef  __ParseFloat
#define __ParseInt() {                                      \
        if (_Val == 0) return void(__fastest_putchar('0')); \
        if (_Val < 0) __fastest_putchar('-'), _Val = -_Val; \
        static int Sta[1 << 5];                             \
        int Top = 0;                                        \
        while (_Val > 0)                                    \
            Sta[++Top] = _Val % 10, _Val /= 10;             \
        while (Top > 0)                                     \
            __fastest_putchar(Sta[Top--] | '0');            \
    }
    extern "C++" inline void __fastcall fwrite(int _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fwrite(long _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fwrite(short _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fwrite(long long _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fwrite(unsigned int _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fwrite(unsigned long _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fwrite(unsigned short _Val) { __ParseInt(); }
    extern "C++" inline void __fastcall fwrite(unsigned long long _Val) { __ParseInt(); }
#undef  __ParseInt
    extern "C++" inline void __fastcall fwrite(char _Ch) { __fastest_putchar(_Ch); }
#define __ParseCharArr() {                                \
        int Ptr = 0;                                      \
        while (_Str[Ptr]) __fastest_putchar(_Str[Ptr++]); \
    }
    extern "C++" inline void __fastcall fwrite(char *_Str) { __ParseCharArr(); }
    extern "C++" inline void __fastcall fwrite(const char *_Str) { __ParseCharArr(); }
#undef  __ParseCharArr
#define __ParseFloat() {                                         \
        __float128 Up = 5;                                       \
        static int Sta[1 << 6];                                  \
        int Top = 0, _It;                                        \
        if (_Val < 0) __fastest_putchar('-'), _Val = -_Val;      \
        for (_It = 0; _It <= _Prec; ++_It) Up /= 10.0;           \
        _Val += Up;                                              \
        long long Par = _Val;                                    \
        _Val -= (__float128)Par;                                 \
        while (Par > 0) Sta[++Top] = Par % 10, Par /= 10;        \
        if (Top == 0) __fastest_putchar('0');                    \
        while (Top > 0) __fastest_putchar(Sta[Top--] | '0');     \
        __fastest_putchar('.'), _It = 0;                         \
        for (; _It < _Prec; ++_It) _Val *= 10;                   \
        Par = _Val, _It = 0;                                     \
        while (Par > 0) Sta[++Top] = Par % 10, Par /= 10;        \
        for (; _It < _Prec - Top; ++_It) __fastest_putchar('0'); \
        while (Top > 0) __fastest_putchar(Sta[Top--] | '0');     \
    }
    extern "C++" inline void __fastcall fwrite(float _Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall fwrite(double _Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall fwrite(__float128 _Val) { __ParseFloat(); }
    extern "C++" inline void __fastcall fwrite(long double _Val) { __ParseFloat(); }
#undef  __ParseFloat
    }
}
#define _anshen                                                             // @Copyright (C,C++) Anshen
#ifndef _ansh_baseio
#define _ansh_baseio                                                        _anshen // pragma once
_anshen namespace anshen {                                                  _anshen // to extends anshenlib
_anshen extern "C++" {                                                      _anshen // to link anshenc++lib-func
_anshen void read(int&);                                                    _anshen // link: read
_anshen void read(long&);                                                   _anshen // link: read
_anshen void read(short&);                                                  _anshen // link: read
_anshen void read(long long&);                                              _anshen // link: read
_anshen void read(unsigned int&);                                           _anshen // link: read
_anshen void read(unsigned long&);                                          _anshen // link: read
_anshen void read(unsigned short&);                                         _anshen // link: read
_anshen void read(unsigned long long&);                                     _anshen // link: read
_anshen void read(float&);                                                  _anshen // link: read
_anshen void read(double&);                                                 _anshen // link: read
_anshen void read(__float128&);                                             _anshen // link: read
_anshen void read(long double&);                                            _anshen // link: read
_anshen void read(char&);                                                   _anshen // link: read
_anshen void read(char*);                                                   _anshen // link: read
_anshen void fread(int&);                                                   _anshen // link: faster read
_anshen void fread(long&);                                                  _anshen // link: faster read
_anshen void fread(short&);                                                 _anshen // link: faster read
_anshen void fread(long long&);                                             _anshen // link: faster read
_anshen void fread(unsigned int&);                                          _anshen // link: faster read
_anshen void fread(unsigned long&);                                         _anshen // link: faster read
_anshen void fread(unsigned short&);                                        _anshen // link: faster read
_anshen void fread(unsigned long long&);                                    _anshen // link: faster read
_anshen void fread(float&);                                                 _anshen // link: faster read
_anshen void fread(double&);                                                _anshen // link: faster read
_anshen void fread(__float128&);                                            _anshen // link: faster read
_anshen void fread(long double&);                                           _anshen // link: faster read
_anshen void fread(char&);                                                  _anshen // link: faster read
_anshen void fread(char*);                                                  _anshen // link: faster read
_anshen }                                                                   _anshen // end of link anshenc++lib-func
_anshen extern "C++" unsigned short _Prec;                                  _anshen // set the float-type precision
_anshen extern "C++" {                                                      _anshen // to link anshenc++lib-func
_anshen void write(int);                                                    _anshen // link: write
_anshen void write(long);                                                   _anshen // link: write
_anshen void write(short);                                                  _anshen // link: write
_anshen void write(long long);                                              _anshen // link: write
_anshen void write(unsigned int);                                           _anshen // link: write
_anshen void write(unsigned long);                                          _anshen // link: write
_anshen void write(unsigned short);                                         _anshen // link: write
_anshen void write(unsigned long long);                                     _anshen // link: write
_anshen void write(float);                                                  _anshen // link: write
_anshen void write(double);                                                 _anshen // link: write
_anshen void write(__float128);                                             _anshen // link: write
_anshen void write(long double);                                            _anshen // link: write
_anshen void write(char);                                                   _anshen // link: write
_anshen void write(char*);                                                  _anshen // link: write
_anshen void write(const char*);                                            _anshen // link: write
_anshen void fwrite(int);                                                   _anshen // link: faster write
_anshen void fwrite(long);                                                  _anshen // link: faster write
_anshen void fwrite(short);                                                 _anshen // link: faster write
_anshen void fwrite(long long);                                             _anshen // link: faster write
_anshen void fwrite(unsigned int);                                          _anshen // link: faster write
_anshen void fwrite(unsigned long);                                         _anshen // link: faster write
_anshen void fwrite(unsigned short);                                        _anshen // link: faster write
_anshen void fwrite(unsigned long long);                                    _anshen // link: faster write
_anshen void fwrite(float);                                                 _anshen // link: faster write
_anshen void fwrite(double);                                                _anshen // link: faster write
_anshen void fwrite(__float128);                                            _anshen // link: faster write
_anshen void fwrite(long double);                                           _anshen // link: faster write
_anshen void fwrite(char);                                                  _anshen // link: faster write
_anshen void fwrite(char*);                                                 _anshen // link: faster write
_anshen void fwrite(const char*);                                           _anshen // link: faster write
_anshen }                                                                   _anshen // end of link anshenc++lib-func
_anshen struct anshenio {                                                   _anshen // start class anshenio
_anshen void set(unsigned short Pre) {                                      _anshen // set the loat-type-output precision
        _Prec = Pre;
_anshen }                                                                   _anshen // end of func
_anshen template <class T>                                                  _anshen // anshenio reader-tool's template part
_anshen anshenio& operator>>(T &Dat) {                                      _anshen // anshenio multi-reader opt >>
        read(Dat);
_anshen return *this;                                                       _anshen // anshenio multi-reader next
_anshen }                                                                   _anshen // end of func
_anshen template <class T>                                                  _anshen // anshenio reader-tool's template part
_anshen anshenio& operator<<(T  Dat) {                                      _anshen // anshenio multi-writer opt <<
        write(Dat);
_anshen return *this;                                                       _anshen // anshenio multi-writer next
_anshen }                                                                   _anshen // end of func
_anshen template <class T>                                                  _anshen // anshenio fast-reader-tool's template part
_anshen anshenio& operator[](T &Dat) {                                      _anshen // anshenio fast-multi-reader opt []
        fread(Dat);
_anshen return *this;                                                       _anshen // anshenio fast-multi-reader next
_anshen }                                                                   _anshen // end of func
_anshen template <class T>                                                  _anshen // anshenio fast-reader-tool's template part
_anshen anshenio& operator()(T  Dat) {                                      _anshen // anshenio fast-multi-writer opt ()
        fwrite(Dat);
_anshen return *this;                                                       _anshen // anshenio fast-multi-writer next
_anshen }                                                                   _anshen // end of func
_anshen void flush() {                                                      _anshen // anshenio fast-multi-writer flush-out
        fwrite((char)-1);
_anshen }                                                                   _anshen // end of func
_anshen } io;                                                               _anshen // end of class anshenio
#define anshenio                                                            _anshen // can't use this class-type
_anshen }                                                                   _anshen // end of anshenc++lib-extend
#undef  _anshen
#endif
#define main                int main                                        //anshen// easy main-func
#define xfor(_i, _s, _e)    for (int _i = (_s); _i <= (_e); ++_i)           //anshen// easy up-for-loop
#define yfor(_i, _s, _e)    for (int _i = (_s); _i >= (_e); --_i)           //anshen// easy down-for-loop
#include <sstream>